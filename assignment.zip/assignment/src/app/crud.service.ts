import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class CrudService {

  constructor(private http: HttpClient) { }

  get(): Observable<any> {
    return this.http.get(`https://65c0cfa6dc74300bce8cc64d.mockapi.io/Contact/profile` );
  }

  post(data:any): Observable<any> {
    return this.http.post(`https://65c0cfa6dc74300bce8cc64d.mockapi.io/Contact/profile`, data );
  }


  put(id:string,data:any): Observable<any> {
    return this.http.put(`https://65c0cfa6dc74300bce8cc64d.mockapi.io/Contact/profile/${id}`, data);
  }

  delete(id:string): Observable<any> {
    return this.http.delete(`https://65c0cfa6dc74300bce8cc64d.mockapi.io/Contact/profile/${id}`);
  }


  

}
