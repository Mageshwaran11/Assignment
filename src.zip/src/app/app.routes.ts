import { Routes } from '@angular/router';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { ContentComponent } from './content/content.component';
export const routes: Routes = [
    { path: 'contact', component: ContactFormComponent },
    { path: 'home', component: ContentComponent },
    { path: '', redirectTo: 'home', pathMatch: 'full' },

];
