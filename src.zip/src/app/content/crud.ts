export interface crudInterface{
    createdAt:Date,
first_name:string,
last_name:string,
emailId:string,
age:number,
gender:string,
mobilenumber:number,
pan_no:string,
adhaar_no:number,
status:string
}