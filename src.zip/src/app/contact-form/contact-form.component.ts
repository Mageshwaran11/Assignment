import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CrudService } from '../crud.service';
import { Subject, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import {HttpClientModule } from '@angular/common/http';
import { crudInterface } from '../content/crud';

@Component({
  selector: 'app-contact-form',
  standalone: true,
  templateUrl: './contact-form.component.html',
  styleUrl: './contact-form.component.scss',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule  // Import HttpClientModule here
  ],
  providers: [CrudService]
})


export class ContactFormComponent {
  
    constructor(protected fb:FormBuilder,private http:CrudService){
      this.contactform=this.fb.group({
        firstname:this.fb.control(null,[Validators.required]),
        lastname:this.fb.control(null,[Validators.required]),
        age:this.fb.control(null),
        gender:this.fb.control(null,[Validators.required]),
        panNo:this.fb.control(null),
        email:this.fb.control(null,[Validators.required]),
        adhaarNo:this.fb.control(null),
        mobilenNo:this.fb.control(null)
      })
    }
    contactform:FormGroup
    protected readonly unsubscribe$ = new Subject<void>();  
    gridData: Array<crudInterface> = [];
    ngOnInit(): void {
    this.getmethod()
    }
    getmethod(){
      this.http.get().pipe(takeUntil(this.unsubscribe$)).subscribe(
        (data:Array<crudInterface> ) => {
          this.gridData=data
        }, 
        (error) => {
          
        }, 
        () => {
          
        }
      );
      
    }

    
}
